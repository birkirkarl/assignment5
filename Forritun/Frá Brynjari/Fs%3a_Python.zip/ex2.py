import re
def ex(s):
    l = []
    g = ['4', '5', '6', '7', '8', '9', '10', 'S', 'M']
    skil = []

    s = s.replace(' ', '')
    s = s.upper()

    for i in s:
        l.append(i)
    print(s)
    print(l)

    if s

print(ex('10s M8')) # 10 S M 8
